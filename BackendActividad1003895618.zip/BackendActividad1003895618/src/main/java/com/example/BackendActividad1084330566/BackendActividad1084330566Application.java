package com.example.BackendActividad1084330566;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendActividad1084330566Application {

	public static void main(String[] args) {
		SpringApplication.run(BackendActividad1084330566Application.class, args);
	}

}
