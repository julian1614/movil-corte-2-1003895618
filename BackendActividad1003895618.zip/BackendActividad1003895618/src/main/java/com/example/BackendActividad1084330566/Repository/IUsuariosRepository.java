package com.example.BackendActividad1084330566.Repository;

import com.example.BackendActividad1084330566.Entity.Usuarios;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IUsuariosRepository extends JpaRepository<Usuarios, Long> {
}
